package com.example.tawazonanimations;


import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.io.IOException;

import pl.droidsonroids.gif.GifDrawable;


/**
 * A simple {@link Fragment} subclass.
 */
public class MyFragment extends Fragment {
    private View gif ;

    public MyFragment() {
        // Required empty public constructor
    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view= inflater.inflate(R.layout.fragment_my, container, false);
        gif = view.findViewById(R.id.gifID);
        gif.setBackgroundResource(  getResources().getIdentifier(getArguments().
                getString("Name"),"drawable",getActivity().getPackageName()));
       /* Paint paint = new Paint();
        paint.setColor(getContext().getColor(android.R.color.black));

        drawRhombus(new Canvas(), paint, 100, 300, 50);
       */ return view;


    }
    /*public void drawRhombus(Canvas canvas, Paint paint, int x, int y, int width) {
        int halfWidth = width / 2;

        Path path = new Path();
        path.moveTo(x, y + halfWidth); // Top
        path.lineTo(x - halfWidth, y); // Left
        path.lineTo(x, y - halfWidth); // Bottom
        path.lineTo(x + halfWidth, y); // Right
        path.lineTo(x, y + halfWidth); // Back to Top
        path.close();

        canvas.drawPath(path, paint);
    }*/
}
